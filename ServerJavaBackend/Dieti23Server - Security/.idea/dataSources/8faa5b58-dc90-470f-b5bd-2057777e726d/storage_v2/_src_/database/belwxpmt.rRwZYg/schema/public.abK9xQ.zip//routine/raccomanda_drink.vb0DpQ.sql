create function raccomanda_drink(id_utente integer)
    returns TABLE(id integer, nome character varying, categoria character varying, descrizione text, prezzo numeric, immagine bytea, punteggio bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            d.id,
            d.nome,
            d.categoria,
            d.descrizione,
            d.prezzo,
            d.immagine::bytea, -- Aggiunta della conversione di tipo
            SUM(CASE WHEN do1.drink_id IN (
                    SELECT drink_id
                    FROM drink_ordine do2
                    WHERE do2.ordine_id IN (
                            SELECT ordine_id
                            FROM drink_ordine
                            WHERE drink_id = d.id AND ordine_id IN (
                                    SELECT ordine.id
                                    FROM ordine
                                    WHERE utente_id = id_utente
                                )
                        ) AND do2.drink_id != d.id
                ) THEN 1 ELSE 0 END) AS punteggio
        FROM
            drink d
            INNER JOIN drink_ordine do1 ON d.id = do1.drink_id
            INNER JOIN ordine o ON do1.ordine_id = o.id
        WHERE
            o.utente_id <> id_utente
        GROUP BY
            d.id
        ORDER BY
            punteggio DESC
        LIMIT 10;
END;
$$;

alter function raccomanda_drink(integer) owner to belwxpmt;


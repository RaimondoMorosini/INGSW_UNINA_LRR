create procedure salva_ordine(in_utente_id integer, in_drink_ids integer[], in_quantita integer[])
    language plpgsql
as
$$
DECLARE
  v_ordine_id INTEGER;
  i INTEGER;
BEGIN
  -- Creazione di un nuovo ordine
  SELECT MAX(id) + 1 INTO v_ordine_id FROM ordine;
  
  INSERT INTO ordine (id, utente_id) VALUES (v_ordine_id, in_utente_id);
  
  -- Inserimento dei drink ordinati
  FOR i IN 1..array_length(in_drink_ids, 1) LOOP
    INSERT INTO drink_ordine (drink_id, ordine_id, quantita, prezzo)
    VALUES (in_drink_ids[i], v_ordine_id, in_quantita[i], (
      SELECT prezzo FROM drink WHERE id = in_drink_ids[i]
    ));
  END LOOP;
END;
$$;

alter procedure salva_ordine(integer, integer[], integer[]) owner to belwxpmt;


create function trg_delete_user_cr() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM utente WHERE email = NEW.email;
    RETURN NULL;
END;
$$;

alter function trg_delete_user_cr() owner to belwxpmt;

